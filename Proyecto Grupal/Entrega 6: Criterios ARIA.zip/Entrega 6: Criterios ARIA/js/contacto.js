sendButton.onclick = function () {
    document.getElementById("Contactanos").reset();
    alert("Mensaje enviado correctamente.");
}